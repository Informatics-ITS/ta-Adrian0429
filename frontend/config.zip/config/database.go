package config

import (
	"fmt"
	"log"
	"os"
	"time"

	"bumisubur-be/constants"

	"github.com/joho/godotenv"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// SetUpDatabaseConnection membuat koneksi database dengan konfigurasi connection pooling
func SetUpDatabaseConnection() *gorm.DB {
	// Load environment variables
	if os.Getenv("APP_ENV") != constants.ENUM_RUN_PRODUCTION {
		err := godotenv.Load(".env")
		if err != nil {
			log.Printf("Warning: .env file not found: %v", err)
		}
	}

	// Database credentials
	dbUser := os.Getenv("DB_USER")
	dbPass := os.Getenv("DB_PASS")
	dbHost := os.Getenv("DB_HOST")
	dbName := os.Getenv("DB_NAME")
	dbPort := os.Getenv("DB_PORT")

	// Construct DSN
	dsn := fmt.Sprintf(
		"host=%v user=%v password=%v dbname=%v port=%v sslmode=disable TimeZone=Asia/Jakarta",
		dbHost, dbUser, dbPass, dbName, dbPort,
	)

	// Konfigurasi logger GORM
	newLogger := logger.New(
		log.New(os.Stdout, "\r\n", log.LstdFlags), // Logger output
		logger.Config{
			SlowThreshold:             time.Second,  // Log query lambat (> 1 detik)
			LogLevel:                  logger.Error, // Hanya log error di production
			IgnoreRecordNotFoundError: true,         // Abaikan error record not found
			Colorful:                  false,        // Nonaktifkan output berwarna
		},
	)

	// Buka koneksi database
	db, err := gorm.Open(postgres.New(postgres.Config{
		DSN:                  dsn,
		PreferSimpleProtocol: true,
	}), &gorm.Config{
		Logger:      newLogger,
		PrepareStmt: true, // Cache prepared statement untuk performa lebih baik
	})

	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}

	// Konfigurasi connection pooling
	sqlDB, err := db.DB()
	if err != nil {
		log.Fatalf("Failed to get database connection: %v", err)
	}

	// Jumlah koneksi idle maksimum dalam pool
	// Nilai ini sebaiknya disesuaikan dengan beban aplikasi
	sqlDB.SetMaxIdleConns(10)

	// Jumlah koneksi maksimum yang dapat dibuka (idle + in-use)
	// Disesuaikan dengan kapasitas database server dan ekspektasi beban
	sqlDB.SetMaxOpenConns(100)

	// Durasi maksimum koneksi dapat idle sebelum ditutup
	sqlDB.SetConnMaxIdleTime(5 * time.Minute)

	// Durasi maksimum sebuah koneksi dapat digunakan sebelum didaur ulang
	// Mencegah "stale connection" issues
	sqlDB.SetConnMaxLifetime(1 * time.Hour)

	// Verifikasi koneksi dengan ping
	if err := sqlDB.Ping(); err != nil {
		log.Fatalf("Failed to ping database: %v", err)
	}

	log.Println("Database connection established successfully with connection pooling")
	return db
}

// CloseDatabaseConnection menutup koneksi database dengan aman
func CloseDatabaseConnection(db *gorm.DB) {
	sqlDB, err := db.DB()
	if err != nil {
		log.Printf("Error getting database connection: %v", err)
		return
	}

	if err := sqlDB.Close(); err != nil {
		log.Printf("Error closing database connection: %v", err)
		return
	}

	log.Println("Database connection closed successfully")
}
